# Shiv Shankar Contact QR

GitHub Pages project for the contact QR in the business-card image.

## Publish

Create a public repository named `contact` under **DarkBrainDB**, then upload the contents of this `contact/` folder to the repository root. Enable GitHub Pages from the repository's `main` branch and `/ (root)` folder.

The QR in the companion HTML points to:

`https://darkbraindb.github.io/contact/contact.vcard`

The `.vcard` file is included because GitHub Pages supports MIME types for static files, and vCard uses the registered `text/vcard` media type.

## Test

After Pages finishes deploying, open the URL above directly on an iPhone and Android phone and test the native contact flow. The exact final confirmation step is controlled by the phone OS.
